package com.example.modul4new

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.navigation.fragment.findNavController

class Profile : Fragment() {

    lateinit var contentNama: String
    lateinit var contentNim : String

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_profile, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        contentNama = arguments?.getString("keyNama").toString()
        contentNim = arguments?.getString("keyNim").toString()

        val tNama = view.findViewById<TextView>(R.id.textNama)
        val tNim = view.findViewById<TextView>(R.id.textNIM)
        val btnBack = view.findViewById<Button>(R.id.backbutton)

        tNama.text = "$contentNama"
        tNim.text = "$contentNim"

        btnBack.setOnClickListener {
            findNavController().navigate(R.id.action_profile_to_home2)
        }

    }

}