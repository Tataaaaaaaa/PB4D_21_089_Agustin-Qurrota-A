package com.example.modul2no2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var dinoList: ArrayList<Dino>
    private lateinit var DinoAdapter: dinoAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView= findViewById(R.id.recyclerView)
        recyclerView.setHasFixedSize(true)
        recyclerView.layoutManager = LinearLayoutManager(this)

        dinoList = ArrayList()

        dinoList.add(Dino(R.drawable.dinoo,"yang ini namanya dino"))
        dinoList.add(Dino(R.drawable.dinoo,"ini namanya brotosaurus"))
        dinoList.add(Dino(R.drawable.dinoo,"ini namanya dilophosaurus"))
        dinoList.add(Dino(R.drawable.dinoo,"ini dino aja sih"))
        dinoList.add(Dino(R.drawable.dinoo,"yang ini spinosaurus"))
        dinoList.add(Dino(R.drawable.dinoo,"yang ini stegosaurus"))
        dinoList.add(Dino(R.drawable.dinoo,"ini T-rex rawr"))
        dinoList.add(Dino(R.drawable.dinoo,"ini triceratops"))
        dinoList.add(Dino(R.drawable.dinoo,"ini kembaran triceratop"))
        dinoList.add(Dino(R.drawable.dinoo,"Menu 10"))
        dinoList.add(Dino(R.drawable.dinoo,"Menu 11"))
        dinoList.add(Dino(R.drawable.dinoo,"Menu 12"))
        dinoList.add(Dino(R.drawable.dinoo,"Menu 13"))
        dinoList.add(Dino(R.drawable.dinoo,"Menu 14"))
        dinoList.add(Dino(R.drawable.dinoo,"Menu 15"))


        DinoAdapter = dinoAdapter(dinoList)
        recyclerView.adapter = DinoAdapter

    }
}