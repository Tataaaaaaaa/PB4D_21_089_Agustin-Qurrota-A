package com.example.modul2no2

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class dinoAdapter(private val dinoList:ArrayList<Dino>)
    : RecyclerView.Adapter<dinoAdapter.dinoViewHolder>(){

    var onItemClik : ((Dino) -> Unit)?= null
    class dinoViewHolder(itemView:View): RecyclerView.ViewHolder(itemView){

        val textView : TextView = itemView.findViewById(R.id.textView)
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): dinoViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.activity_item,parent,false ,)
        return dinoViewHolder(view)
    }
    override fun onBindViewHolder(holder: dinoViewHolder, position: Int) {
        val dino =dinoList[position]

        holder.textView.text = dino.name

        holder.itemView.setOnClickListener{
            onItemClik?.invoke(dino)
        }
    }

    override fun getItemCount(): Int {
        return dinoList.size
    }


}