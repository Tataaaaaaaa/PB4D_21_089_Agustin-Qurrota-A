package com.example.modul2no2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Item : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_item)
    }
}